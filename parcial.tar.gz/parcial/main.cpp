#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>

//Hecho por ANA RUTH SANCHEZ HERNRIQUEZ

//Definimos variables
double rotate_x=0;
double rotate_y=0;
double rotate_z=0;

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;



void piesas(){
	glPushMatrix();
    //Dibujando el Cubo base Color Azul
    glColor3f(0.0, 0.0, 1.0);
    glTranslated(0.0f, -0.5f, 0.0f);
    glutSolidCube(0.2);
    glPopMatrix();
    glPushMatrix();
    
    //Dibujando el Mastil base Color Rojo
    glColor3f(1.0, 0.0, 0.0);
		glTranslated(0.0f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glTranslated(0.0f, 0.4f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glTranslated(0.0f, 0.3f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, 0.2f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, 0.1f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, 0.0f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, -0.1f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, -0.2f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, -0.3f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glTranslated(0.0f, -0.4f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    
    
		//Barra Horizontal
    glColor3f(0.2, 0.4, 1.0);
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.1f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.2f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.3f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.4f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    
    //Barra Vertical
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.4f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.3f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.2f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.1f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
    glTranslated(0.5f, 0.0f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    
    
		//Cable
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.35f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.30f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.25f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.20f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.15f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.10f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.05f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, 0.0f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.05f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.10f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.15f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.20f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.25f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.30f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.35f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.40f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.45f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.50f, 0.0f);
    glutSolidCube(0.05);
    glPopMatrix();
    glPushMatrix();
    
    
		//Cubo Negro
		glColor3f(0.0, 0.0, 0.0);
		glRotatef( rotate_x, 0.0, 1.0, 0.0 );
		glTranslatef(X, Y, Z);
    glTranslated(0.5f, -0.55f, 0.0f);
    glutSolidCube(0.08);
    glPopMatrix();
    glPushMatrix();
    
    //Cubo #1 Color Verde
    glColor3f(0.0, 1.0, 0.0);
    glTranslated(-0.4f, -0.5f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    
    //Cubo #2 color rojo
    glColor3f(1.0, 0.0, 0.0);
    glTranslated(-0.3f, -0.8f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    
    //Cubo #3 Color Amarillo
    glColor3f(1.0, 1.0, 0.0);
    glTranslated(0.5f, -0.7f, 0.0f);
    glutSolidCube(0.1);
    glPopMatrix();
    glPushMatrix();
    glEnd();
    glFlush();
    glutSwapBuffers();

}

void display()
{
    glClearColor(1,1,1,0.5);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );
    glLoadIdentity();
    glScalef(scale, scale, scale);
    piesas();
}


// TECLAS ESPECIALES
void specialKeys( int key, int x, int y )
{


    if (key == GLUT_KEY_RIGHT)
        rotate_x += 15;

    if (key == GLUT_KEY_LEFT)
        rotate_x -= 15;

		if (key == GLUT_KEY_UP)
					if(Y<=0.1)
					{
						Y += 0.01f;
					}

		if (key == GLUT_KEY_DOWN)
					if(Y >=-0.4)
					{
						Y -= 0.01f;
					}
    //  ACTUALIZACION
    glutPostRedisplay();
}

int main(int argc, char* argv[])
{

    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);

    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 600);
    glutInitWindowPosition (0, 0);
    // Crear ventana
    glutCreateWindow("parcial");

    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);

    // Funciones de retrollamada
    glutDisplayFunc(display);
    glutSpecialFunc(specialKeys);

    // Pasar el control de eventos a GLUT
    glutMainLoop();

    // Regresar al sistema operativo
    return 0;
}
