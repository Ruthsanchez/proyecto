#include <GL/gl.h>
#include <GL/glut.h>
#include <stdio.h>

//ANA RUTH SANCHEZ HENRIQUEZ SH13012

void display(void)
{
    // Propiedades del material
    GLfloat mat_ambient[] = { 0.0215f, 0.1745f, 0.0215f,1.0f };
    GLfloat mat_diffuse[] = { 0.07568f, 0.61424f, 0.07568f, 1.0f };
    GLfloat mat_specular[] = { 0.633f, 0.727811f, 0.633f, 1.0f };
    GLfloat shine[] = {50};
    // "Limpiamos" el frame buffer con el color de "Clear", en este
    // caso negro.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );
    glLoadIdentity();
    //setMaterial
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
    glTranslatef(-20,-20,0);
    glRotatef(20,1,0,0);
    glRotatef(-15,0,1,0);
    
    // dibujamos las figuras
    glTranslatef(0,75,110);
    glPushMatrix();
    
    GLfloat light_position[] = { -100, 100.0, 125.0, 1}; 
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);

    //color de la esfera 
    mat_ambient[0]= 0.135f, mat_ambient[1]=0.2225f, mat_ambient[2]= 0.1575f;       
    mat_diffuse[0]= 0.54f, mat_diffuse[1]=0.89f, mat_diffuse[2]= 0.63f; 
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glTranslatef(-100,0,0);
    //dibujamos la esfera
    glutSolidSphere(40,50,50);  
    glPopMatrix();
    glPushMatrix();
    glRotatef(-15,0,1,0);
    glRotatef(10,1,0,0);
    
   
    //color del cubo 
    mat_ambient[0]= 0.1745f, mat_ambient[1]=0.01175f, mat_ambient[2]= 0.01175f;
    mat_diffuse[0]= 0.61424f, mat_diffuse[1]=0.04136f, mat_diffuse[2]= 0.04136f;
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    //dibujamos el cubo
    glutSolidCube(50); 
    glPopMatrix();
    glPushMatrix();

    //color del cono 
    mat_ambient[0]= 0.2125f, mat_ambient[1]=0.1275f, mat_ambient[2]= 0.054f;
    mat_diffuse[0]= 0.714f, mat_diffuse[1]=0.4284f, mat_diffuse[2]= 0.18144f;
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glTranslatef(100,-25,0);
    glRotatef(-90,1,0,0);
    //dibujamos el cono
    glutSolidCone(50,70,10,25); 
    glPopMatrix();
    glFlush();
}

void reshape(int w, int h)
{
    glViewport(0, 0,  (GLsizei) w, (GLsizei) h);
    // Activamos la matriz de proyeccion.
    glMatrixMode(GL_PROJECTION);
    // "limpiamos" esta con la matriz identidad.
    glLoadIdentity();
    // Usamos proyeccion ortogonal
    glOrtho(-200, 200, -200, 200, -200, 200);
    // Activamos la matriz de modelado/visionado.
    glMatrixMode(GL_MODELVIEW);
    // "Limpiamos" la matriz
    glLoadIdentity();
}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB|GLUT_DEPTH);
    glutInitWindowSize(640,480);
    glutInitWindowPosition(100,100);
    glutCreateWindow ("cubo,cono y esfera");
    glClearColor(0,0,1,0.0);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);
    glutMainLoop();

return 0;

}
