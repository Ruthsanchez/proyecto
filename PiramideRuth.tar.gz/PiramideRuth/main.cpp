#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>

//HECHO POR ANA RUTH SANCHEZ
//ALGORITMOS



//VARIABLES
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
GLfloat scale = 1.0f;

double r=1.0;
double g=1.0;
double b=1.0;

void init(void)
{
	// FUENTE DE LUZ
    GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };// SE ACTIVA FUENTE DE LUZ
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0); 
	glDepthFunc(GL_LESS); 
	glEnable(GL_DEPTH_TEST); 
	glLightfv(GL_LIGHT0,GL_POSITION,light_position);
	
	
	// CARAS FRONTALES
	// COLOR SOLIDO DE RELLENO
    glPolygonMode(GL_FRONT, GL_FILL);

}
	//FUNCION PARA DAR COLOR AL TRIANGULO
	void color(float a1, float a2, float a3, float d1, float d2, float d3, float s1, float s2, float s3, float a4)
	{
		GLfloat mat_ambient[] = { a1, a2, a3, a4 };
		GLfloat mat_diffuse[] = { d1, d2, d3, a4 };
		GLfloat mat_specular[] = { s1, s2, s3, a4 };
		GLfloat shine[] = {a4};

		glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
		glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
		glMaterialfv(GL_FRONT, GL_SHININESS, shine);

	}
		
	void reshape(int w, int h)
	{
		glViewport(0, 0, (GLsizei) w, (GLsizei) h);
		// MATRIZ DE PROYECCION
		glMatrixMode(GL_PROJECTION);
		// LIMPIA LA MATRIZ.
		glLoadIdentity();
		// PROYECCION ORTOGONAL
		glOrtho(-1, 1, -1, 1, -1, 1);
		// ACTIVAR MATRIZ
		glMatrixMode(GL_MODELVIEW);
		// "Limpiamos" la matriz
		glLoadIdentity();
	}

	void display(void)
	{


		// "Limpiamos" el frame buffer con el color de "Clear", en este
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glMatrixMode( GL_MODELVIEW_MATRIX );
		glLoadIdentity();
		// Rotar en el eje X,Y
		glRotatef( rotate_x, 1.0, 0.0, 0.0 );
		glRotatef( rotate_y, 0.0, 1.0, 0.0 );
		glPushMatrix();

glEnable(GL_NORMALIZE);

		//Dibujamos un triangulo
		
		glBegin(GL_POLYGON);
		//Le pasamos valores a la funcion para agregar color y material
		color(0.0f, 0.1f, 0.06f,0.0f, 0.50980392f, 0.50980392f,0.50196078f, 0.50196078f, 0.50196078f,0.25f);
		//Suavisamos los bordes
		glShadeModel(GL_SMOOTH);
		
		glColor3f( r, g, b );
		glNormal3f(1.0f, 1.0f, 1.0f);
		glColor3f( r, g, b );
		glVertex3f(0.3, -0.3, -0.3 );
		glColor3f( r, g, b );
		glNormal3f(1.0f, 1.0f, 1.0f);
		glColor3f( r, g, b );
		glVertex3f(0.3, -0.3,  0.3 );
		glColor3f( r, g, b );
		glNormal3f(1.0f, 1.0f, 1.0f);
		glColor3f( r, g, b );
		glVertex3f(-0.3, -0.3,  0.3 );
		glColor3f( r, g, b );
		glNormal3f(1.0f, 1.0f, 1.0f);
		glColor3f( r, g, b );
		glVertex3f(-0.3, -0.3, -0.3 );
		glEnd();

		//Parte delantera de triangulo
		glBegin(GL_TRIANGLES);
		glColor3f( r, g, b );
		color(0.0,0.03,0.04,0.2,0.4,0.6,0.03,0.6,0.8,0.5f );
		glShadeModel(GL_SMOOTH);
		
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3d(  0.3, -0.3, -0.3 );      
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3d(  0.0,  0.3, 0.0 );     
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3d( -0.3,  -0.3, -0.3 );
		glEnd();

		//Parte de atras del triangulo
		glBegin(GL_TRIANGLES);
		glColor3f( r, g, b );
		color(0.1,0.0,0.1,0.4,0.1,0.0,0.5,0.6,0.5,0.20f );
		glShadeModel(GL_SMOOTH);
		
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(  0.3, -0.3, 0.3 );      
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(  0.0,  0.3, 0.0 );      
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f( -0.3,  -0.3, 0.3 );    
		glEnd();

		//Parte derecha del triangulo
		glBegin(GL_TRIANGLES);
		glColor3f( r, g, b );
		color(0.0f, 0.0, 0.0f,0.1f, 0.35f, 0.1f,0.45f, 0.55f, 0.45f,0.25f);
		glShadeModel(GL_SMOOTH);
		
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(0.3, -0.3, -0.3 );
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(0.3,  -0.3, 0.3 );
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(0.0,  0.3,  0.0 );
		glEnd();

		//Parte izquierda del triangulo
		glBegin(GL_TRIANGLES);
		glColor3f( r, g, b );
		color(0.03f, 0.02, 0.1f,0.6f, 0.2f, 0.5f,0.6f, 0.5f, 0.03f,0.07812f);
		
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(-0.3, -0.3,  0.3 );
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(0.0,  0.3,  0.0 );
		glNormal3f(-1.0f, 0.0f, 1.0f);
		glVertex3f(-0.3,  -0.3, -0.3 );
		glEnd();

		glFlush();
	}
		void specialKeys( int key, int x, int y )
{

		//  Flecha derecha: aumentar rotación 7 grados
	if (key == GLUT_KEY_RIGHT)
        rotate_y += 7;

		//  Flecha izquierda: rotación en eje Y negativo 7 grados
    else if (key == GLUT_KEY_LEFT)
        rotate_y -= 7;
		//  Flecha arriba: rotación en eje X positivo 7 grados
    else if (key == GLUT_KEY_UP)
        rotate_x += 7;
		//  Flecha abajo: rotación en eje X negativo 7 grados
    else if (key == GLUT_KEY_DOWN)
        rotate_x -= 7;
        
		//  Solicitar actualización de visualización
		glutPostRedisplay();
	}

// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
    case 's':
        scale=0.5;
        break;
    case 'd':
        scale=1.5;
        break;
    case 'x' :
        X += 0.1f;
        break;
    case 'X' :
        X -= 0.1f;
        break;
    case 'y' :
        Y += 0.1f;
        break;
    case 'Y' :
        Y -= 0.1f;
        break;
    case 'z':
        Z -= 0.1f;
        break;
    case 'Z':
        Z += 0.1f;
        break;
    case '1':
       r=0;
       g=1;
       b=0;
        break;
    case '2':
       r=1;
       g=1;
       b=0;
        break;
    case '3':
       r=1;
       g=0;
       b=1;
        break;
    case '4':
       r=3;
       g=0;
       b=0;
        break;
    case '5':
       r=5;
       g=1;
       b=2;
        break;
    case 'q':
        exit(0);			// exit
    }
    glutPostRedisplay();
}

	int main(int argc, char **argv)
	{
		// Inicializo OpenGL
		glutInit(&argc, argv);
		// Activamos buffer simple y colores del tipo RGB
		glutInitDisplayMode (GLUT_RGB | GLUT_DEPTH);
		// Definimos una ventana de medidas 800 x 600 como ventana
		// de visualizacion en pixels
		glutInitWindowSize (800, 600);
		// Posicionamos la ventana en la esquina superior izquierda de
		// la pantalla.
		glutInitWindowPosition (0, 0);
		// Creamos literalmente la ventana y le adjudicamos el nombre que se
		// observara en su barra de titulo.
		glutCreateWindow ("Triangulo");
		// Inicializamos el sistema
		init();
		glutDisplayFunc(display);
		glutReshapeFunc(reshape);
		glutKeyboardFunc(keyboard);
		glutSpecialFunc(specialKeys);

		glutMainLoop();
		return 0;
	}
